<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of adminController
 *
 * @author lixiaoxin
 */
class WnewsController extends Controller {

    public $SECRET_KEY = "hXVBQPSennzh46Xp";

    public function init() {
        if (Yii::app()->request->getParam("key", "") != $this->SECRET_KEY) {
            echo "wrong key!";
            Yii::app()->end();
        }
    }

}

?>
