<?php

class ApiController extends WnewsController {

    public function actionIndex() {
        
    }

    public function actionNewsList($category_id = 0) {
        $data = array();
        if ($category_id > 0) {
            $query = Yii::app()->db->createCommand()->select('*')->from('{{news}}')->where("category_id=:category_id", array(":category_id" => $category_id))->limit('20')->order('dateline')->query();
        } else {
            $query = Yii::app()->db->createCommand()->select('*')->from('{{news}}')->limit('20')->order('dateline DESC')->query();
        }

        while ($row = $query->read()) {
            $row['dateline'] = date("Y-m-d H:i:s", $row['dateline']);
            $data[] = $row;
        }
        $this->jsonEcho($data);
    }

    public function actionNews($id) {
        $data = $jsondata = array();
        $query = Yii::app()->db->createCommand()->select('*')->from('{{news}}')->where("id=:id", array(":id" => $id))->query();
        while ($row = $query->read()) {
            $row['dateline'] = date("Y-m-d H:i:s", $row['dateline']);
            $data[] = $row;
        }
        $this->jsonEcho($data);
    }

    public function actionSearch($keyword = "") {
        $data = array();

        if (!empty($keyword)) {
            $command = Yii::app()->db->createCommand();
            $command->select('*');
            $command->from('{{news}}');
            $command->where(array('like', 'title', '%' . $keyword . '%'));
            $command->order('dateline DESC');
            $command->limit("20");

            $query = $command->queryAll();
            foreach ($query as $row) {
                $row['dateline'] = date("Y-m-d H:i:s", $row['dateline']);
                $data[] = $row;
            }
        }

        $this->jsonEcho($data);
    }
    
    public function actionLogin(){
        $data = array();
        $username = Yii::app()->request->getParam("username", "");
        $password = Yii::app()->request->getParam("password", "");
        $data["code"] = -1;
        $data["userinfo"] = "";
        $data["userinfo"]["id"] =  0;
        $data["userinfo"]["username"] =  "";
        $data["userinfo"]["email"] = "";
        if (!empty($username) && !empty($password)) {
            $userinfo = Users::model()->find("username=:username and password=:password", array(":username"=>  strtolower($username), ":password"=>strtolower($password)));    
            if (!empty($userinfo)) {
                $data["code"] = 1;
                $data["userinfo"]["id"] =  $userinfo->id;
                $data["userinfo"]["username"] =  $userinfo->username;
                $data["userinfo"]["email"] = $userinfo->email;
                
                $setting = unserialize($userinfo->settings);
                if(!empty($setting)){
                    foreach($setting as $key=>$value){
                        $data["userinfo"][$key] = $value;
                    }
                }  
            }
        }

        $this->jsonEcho($data);
    }
    
    
public function actionSettingsUpdate(){
        $data = $settingsData = array();
        
        $settings = Yii::app()->request->getParam("settings", "");
        $uid = Yii::app()->request->getParam("uid", 0);
        if (!empty($settings) && !empty($uid)) {
            $settingsData = json_decode($settings, 1);
            $model=Users::model()->findByPk($uid);
            if($model){
                $model->email = $settingsData['email'];
                $model->settings = serialize($settingsData);
                $model->save();
            }
        }

        $this->jsonEcho($data);
    }

    public function actionCategories() {
        $data = array(
            array("name"=>"Top news", "id"=> 0),
            array("name"=>"Sport", "id"=> 1),
            array("name"=>"National", "id"=> 2),
        );

        $this->jsonEcho($data);
    }

    public function jsonEcho($content) {
        $jsondata = array();
        $jsondata['datas'] = $content;
        echo json_encode($jsondata);
        Yii::app()->end();
    }

}